const homePage = document.querySelector(".main-header")

homePage.addEventListener("click", ()=>{
    document.location.href = 'index.html'
})